# SonarQube unit coverage collection evidence

Existing test suites executed: **7**

Format: **OpenCover XML** collected with `coverlet.collector`.
Filter: `Category!=DatabaseIntegration` (same as existing group unit workflow).
Reports are imported by `sonar.cs.opencover.reportsPaths` at SonarScanner end.
This file records collector output, not an estimated coverage percentage.

Reports:
- `artifacts/code-quality/sonar/ci/coverage/ResearchTrack.AuthService.Tests/4b9b9662-09a3-4a09-987d-345bf512e719/coverage.opencover.xml`
- `artifacts/code-quality/sonar/ci/coverage/ResearchTrack.Gateway.Tests/b7243680-d0f5-4572-9653-b6d91303f898/coverage.opencover.xml`
- `artifacts/code-quality/sonar/ci/coverage/ResearchTrack.GitHubService.Tests/6410ffde-c7ff-4f52-b27f-2fb4e64bca18/coverage.opencover.xml`
- `artifacts/code-quality/sonar/ci/coverage/ResearchTrack.JiraService.Tests/bd827420-b08a-4d63-a495-ba98ec7b777a/coverage.opencover.xml`
- `artifacts/code-quality/sonar/ci/coverage/ResearchTrack.MeetingService.Tests/cafc7846-aa84-46c3-acd1-9027172ce1f2/coverage.opencover.xml`
- `artifacts/code-quality/sonar/ci/coverage/ResearchTrack.ProjectService.Tests/33cbfea0-66b9-484a-8166-97bbe3b35932/coverage.opencover.xml`
- `artifacts/code-quality/sonar/ci/coverage/ResearchTrack.SubmissionService.Tests/f3029dd0-a2f6-47a6-ad2c-ff9491a1246e/coverage.opencover.xml`
